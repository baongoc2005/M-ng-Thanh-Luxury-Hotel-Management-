import React from 'react';
import { 
  LayoutDashboard, 
  Hotel, 
  Bed, 
  Users, 
  BarChart3, 
  CalendarDays, 
  Wallet, 
  Settings, 
  LogOut, 
  Bell, 
  HelpCircle, 
  Search,
  Plus,
  ChevronRight,
  MoreVertical,
  Eye,
  Edit,
  Trash2,
  TrendingUp,
  CheckCircle2,
  X,
  MapPin,
  Mail,
  Phone,
  Info,
  CloudUpload,
  Shield,
  BellRing,
  Settings2,
  UserPlus,
  History,
  Star,
  Lock,
  RefreshCw,
  MessageSquare,
  Filter,
  Download,
  Calendar,
  User,
  CreditCard,
  Wifi,
  Utensils,
  Dumbbell,
  Flower2,
  Car,
  Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---

type View = 'dashboard' | 'hotels' | 'add-hotel' | 'bookings' | 'customers' | 'settings';

// --- Components ---

const Sidebar = ({ currentView, setView }: { currentView: View, setView: (v: View) => void }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'hotels', label: 'Hotel Management', icon: Hotel },
    { id: 'bookings', label: 'Booking Management', icon: CalendarDays },
    { id: 'customers', label: 'Customer Management', icon: Users },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-slate-50 dark:bg-slate-950 border-r border-slate-200/50 dark:border-slate-800/50 flex flex-col p-4 z-50">
      <div className="mb-10 px-4 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-[#904d00] flex items-center justify-center text-white shadow-lg">
          <Hotel size={24} />
        </div>
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100 font-headline">Muong Thanh</h2>
          <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Luxury Atelier</p>
        </div>
      </div>

      <nav className="flex-1 space-y-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id as View)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 font-medium text-sm ${
              currentView === item.id || (currentView === 'add-hotel' && item.id === 'hotels')
                ? 'bg-white dark:bg-slate-900 text-[#904d00] shadow-sm font-bold scale-95' 
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-200/50 dark:hover:bg-slate-800/50'
            }`}
          >
            <item.icon size={18} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="mt-auto pt-6 border-t border-slate-200/50">
        <button 
          onClick={() => setView('add-hotel')}
          className="w-full bg-gradient-to-br from-[#904d00] to-[#ff8c00] text-white py-3 rounded-xl font-bold text-sm shadow-md hover:shadow-lg transition-all mb-6 flex items-center justify-center gap-2 active:scale-95"
        >
          <Plus size={16} />
          Add New Property
        </button>
        <div className="space-y-1">
          <button className="w-full flex items-center gap-3 px-4 py-3 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 transition-colors text-sm font-medium">
            <HelpCircle size={18} />
            <span>Support</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 text-slate-500 dark:text-slate-400 hover:text-red-600 transition-colors text-sm font-medium">
            <LogOut size={18} />
            <span>Logout</span>
          </button>
        </div>
      </div>
    </aside>
  );
};

const Topbar = ({ title, breadcrumbs }: { title: string, breadcrumbs?: string[] }) => {
  return (
    <header className="sticky top-0 z-40 flex justify-between items-center px-8 h-16 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200/50 dark:border-slate-800/50 shadow-sm">
      <div className="flex items-center gap-6 flex-1">
        {breadcrumbs && (
          <div className="flex items-center gap-2 text-slate-500 font-headline text-sm">
            {breadcrumbs.map((bc, i) => (
              <React.Fragment key={bc}>
                <span className={i === breadcrumbs.length - 1 ? "text-slate-900 font-bold" : ""}>{bc}</span>
                {i < breadcrumbs.length - 1 && <ChevronRight size={14} />}
              </React.Fragment>
            ))}
          </div>
        )}
        {!breadcrumbs && <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100 font-headline">{title}</h2>}
        
        <div className="relative w-full max-w-md ml-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            className="w-full bg-slate-100 dark:bg-slate-800 border-none rounded-lg pl-10 pr-4 py-2 text-sm focus:ring-2 focus:ring-[#904d00]/20 placeholder:text-slate-400" 
            placeholder="Search hotels, IDs, or staff..." 
            type="text" 
          />
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-3">
          <button className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-all relative">
            <Bell size={20} />
            <span className="absolute top-2 right-2 w-2 h-2 bg-orange-500 rounded-full border-2 border-white"></span>
          </button>
          <button className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-all">
            <HelpCircle size={20} />
          </button>
          <button className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-all">
            <Settings size={20} />
          </button>
        </div>
        <div className="h-8 w-[1px] bg-slate-200 dark:bg-slate-700 mx-1"></div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-sm font-bold text-slate-900 dark:text-slate-100 leading-none">Alexander Thorne</p>
            <p className="text-[10px] text-slate-500 font-medium uppercase tracking-tight mt-1">Super Admin</p>
          </div>
          <img 
            className="w-10 h-10 rounded-full object-cover border-2 border-[#ffdcc3] shadow-sm" 
            src="https://picsum.photos/seed/admin/100/100" 
            alt="Admin Avatar" 
          />
        </div>
      </div>
    </header>
  );
};

// --- Views ---

const DashboardView = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Total Rooms', value: '1,240', change: 'Available across all branches', icon: Bed, color: 'blue' },
          { label: 'Total Bookings', value: '856', change: '+14.2% this month', icon: CalendarDays, color: 'indigo' },
          { label: 'Total Revenue', value: '$124,500', change: 'Total revenue this month', icon: Wallet, color: 'amber' },
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-start justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500 mb-1">{stat.label}</p>
              <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">{stat.value}</h3>
              <p className={`text-xs ${stat.color === 'amber' ? 'text-slate-400 italic' : 'text-emerald-600 bg-emerald-50 dark:bg-emerald-900/30 px-2 py-1 rounded-lg inline-flex items-center gap-1 font-semibold'}`}>
                {stat.color !== 'amber' && <TrendingUp size={12} />}
                {stat.change}
              </p>
            </div>
            <div className={`w-12 h-12 bg-${stat.color}-50 dark:bg-${stat.color}-900/20 rounded-xl flex items-center justify-center text-${stat.color}-600`}>
              <stat.icon size={24} />
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-slate-900 dark:text-white">Booking Statistics</h3>
            <span className="text-xs font-medium text-slate-400">Mon - Sun</span>
          </div>
          <div className="h-48 flex items-end justify-between gap-2 px-2">
            {[40, 55, 45, 75, 65, 95, 85].map((h, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
                <div 
                  className="w-full bg-[#904d00]/20 group-hover:bg-[#904d00] rounded-t-lg transition-all duration-300" 
                  style={{ height: `${h}%` }}
                ></div>
                <span className="text-[10px] font-bold text-slate-400">{['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'][i]}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-slate-900 dark:text-white">Revenue Growth</h3>
            <span className="text-xs font-medium text-slate-400">Week 1 - Week 4</span>
          </div>
          <div className="h-48 relative">
            <svg className="w-full h-full" viewBox="0 0 400 150" preserveAspectRatio="none">
              <path 
                d="M0,110 C50,115 100,60 150,85 C200,110 250,30 300,50 C350,70 400,10" 
                fill="none" 
                stroke="#904d00" 
                strokeWidth="3" 
              />
              <circle cx="150" cy="85" r="4" fill="#904d00" />
              <circle cx="300" cy="50" r="4" fill="#904d00" />
              <circle cx="400" cy="10" r="4" fill="#904d00" />
            </svg>
            <div className="flex justify-between mt-4">
              {['WK 1', 'WK 2', 'WK 3', 'WK 4'].map(wk => (
                <span key={wk} className="text-[10px] font-bold text-slate-400">{wk}</span>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
          <h3 className="font-bold text-slate-900 dark:text-white">Recent Bookings</h3>
          <button className="text-sm font-semibold text-[#904d00] hover:underline">View All</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/50 text-[11px] font-bold text-slate-500 uppercase tracking-widest">
                <td className="px-6 py-4">Booking ID</td>
                <td className="px-6 py-4">Customer</td>
                <td className="px-6 py-4">Hotel & Room</td>
                <td className="px-6 py-4">Dates</td>
                <td className="px-6 py-4">Status</td>
                <td className="px-6 py-4">Total Price</td>
                <td className="px-6 py-4">Action</td>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {[
                { id: '#MT-88421', name: 'Sarah Miller', initial: 'SM', hotel: 'Muong Thanh Da Nang', room: 'Deluxe Sea View', dates: 'Oct 12 - 15', nights: '3 nights', status: 'Checked In', price: '$450.00', color: 'emerald' },
                { id: '#MT-88422', name: 'James Wilson', initial: 'JW', hotel: 'Muong Thanh Luxury Saigon', room: 'Executive Suite', dates: 'Oct 14 - 16', nights: '2 nights', status: 'Confirmed', price: '$320.00', color: 'blue' },
                { id: '#MT-88423', name: 'Laura Lee', initial: 'LL', hotel: 'Muong Thanh Ha Noi', room: 'Superior Double', dates: 'Oct 20 - 22', nights: '2 nights', status: 'Pending', price: '$180.00', color: 'slate' },
              ].map((row, i) => (
                <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                  <td className="px-6 py-4 font-mono text-xs text-slate-500">{row.id}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full bg-${row.color}-100 text-${row.color}-700 flex items-center justify-center text-[10px] font-bold`}>{row.initial}</div>
                      <span className="text-sm font-medium">{row.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm font-medium">{row.hotel}</p>
                    <p className="text-xs text-slate-500">{row.room}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm">{row.dates}</p>
                    <p className="text-[10px] text-slate-400">{row.nights}</p>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold bg-${row.color}-100 text-${row.color}-700 uppercase`}>{row.status}</span>
                  </td>
                  <td className="px-6 py-4 font-semibold text-sm">{row.price}</td>
                  <td className="px-6 py-4 text-slate-400 hover:text-[#904d00] cursor-pointer">
                    <Eye size={18} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const HotelManagementView = ({ onAdd }: { onAdd: () => void }) => {
  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end">
        <div className="space-y-1">
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight font-headline">Hotel Management</h1>
          <p className="text-slate-500 text-sm">Oversee and manage the global Muong Thanh luxury property portfolio.</p>
        </div>
        <button 
          onClick={onAdd}
          className="bg-gradient-to-r from-[#904d00] to-[#ff8c00] text-white px-6 py-3 rounded-full font-bold shadow-md hover:scale-[1.02] active:scale-95 transition-all flex items-center gap-2"
        >
          <Plus size={18} />
          Add New Hotel
        </button>
      </div>

      <div className="grid grid-cols-12 gap-4">
        <div className="col-span-12 lg:col-span-8 bg-white p-4 rounded-2xl shadow-sm flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-3 px-4 py-2 bg-slate-50 rounded-xl border border-transparent focus-within:border-[#ffdcc3] transition-all">
            <MapPin size={16} className="text-slate-400" />
            <select className="bg-transparent border-none text-sm font-medium focus:ring-0 p-0 pr-8">
              <option>All Cities</option>
              <option>Hanoi</option>
              <option>Da Nang</option>
            </select>
          </div>
          <div className="flex items-center gap-3 px-4 py-2 bg-slate-50 rounded-xl border border-transparent focus-within:border-[#ffdcc3] transition-all">
            <RefreshCw size={16} className="text-slate-400" />
            <select className="bg-transparent border-none text-sm font-medium focus:ring-0 p-0 pr-8">
              <option>All Status</option>
              <option>Active</option>
              <option>Maintenance</option>
            </select>
          </div>
          <button className="ml-auto flex items-center gap-2 px-5 py-2 text-[#435b9f] font-semibold hover:bg-blue-50 rounded-xl transition-all">
            <Search size={16} />
            Advanced Filters
          </button>
        </div>
        <div className="col-span-12 lg:col-span-4 bg-white p-4 rounded-2xl shadow-sm flex items-center gap-4">
          <div className="flex-1 flex items-center gap-3 px-4 py-2 bg-slate-50 rounded-xl">
            <Search size={16} className="text-slate-400" />
            <input className="bg-transparent border-none text-sm focus:ring-0 p-0 w-full" placeholder="Quick find hotel..." type="text" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-sm overflow-hidden border border-slate-100">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500">Hotel ID</th>
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500">Hotel Name</th>
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500">City</th>
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500">Address</th>
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500 text-center">Total Rooms</th>
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500">Status</th>
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[
                { id: 'MT-LX-001', name: 'Muong Thanh Luxury Da Nang', city: 'Da Nang', address: '270 Vo Nguyen Giap, Bac My Phu, Ngu Hanh Son', rooms: 350, status: 'Active', isNew: true },
                { id: 'MT-LX-002', name: 'Muong Thanh Luxury Centre', city: 'Hanoi', address: '123 Le Duan, Hoan Kiem District', rooms: 450, status: 'Active' },
                { id: 'MT-LX-005', name: 'Muong Thanh Luxury Riverside', city: 'Da Nang', address: '92 Vo Nguyen Giap, Son Tra', rooms: 320, status: 'Active' },
                { id: 'MT-LX-012', name: 'Muong Thanh Luxury Boutique', city: 'Ho Chi Minh City', address: '45 Pasteur St, District 1', rooms: 180, status: 'Maintenance' },
              ].map((hotel, i) => (
                <tr key={i} className={`hover:bg-slate-50 transition-colors group ${hotel.isNew ? 'bg-orange-50/30' : ''}`}>
                  <td className="px-6 py-5 font-mono text-xs text-[#435b9f] font-bold">{hotel.id}</td>
                  <td className="px-6 py-5 font-headline font-bold text-slate-900">
                    <div className="flex items-center gap-2">
                      {hotel.name}
                      {hotel.isNew && <span className="bg-orange-500 text-white text-[8px] px-1.5 py-0.5 rounded-full uppercase tracking-tighter">New</span>}
                    </div>
                  </td>
                  <td className="px-6 py-5 text-sm text-slate-500">{hotel.city}</td>
                  <td className="px-6 py-5 text-sm text-slate-500 max-w-xs truncate">{hotel.address}</td>
                  <td className="px-6 py-5 text-center">
                    <span className={`text-sm font-bold ${hotel.isNew ? 'bg-orange-100 text-orange-700' : 'bg-blue-50 text-blue-700'} px-3 py-1 rounded-full`}>{hotel.rooms}</span>
                  </td>
                  <td className="px-6 py-5">
                    <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full ${hotel.status === 'Active' ? 'bg-emerald-50 text-emerald-700' : 'bg-orange-50 text-orange-700'} w-fit`}>
                      <div className={`w-1.5 h-1.5 rounded-full ${hotel.status === 'Active' ? 'bg-emerald-500' : 'bg-orange-500'}`}></div>
                      <span className="text-[11px] font-bold uppercase tracking-wide">{hotel.status}</span>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 transition-all"><Eye size={18} /></button>
                      <button className="p-2 hover:bg-orange-50 rounded-lg text-[#904d00] transition-all"><Edit size={18} /></button>
                      <button className="p-2 hover:bg-red-50 rounded-lg text-red-600 transition-all"><Trash2 size={18} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-8 py-6 flex justify-between items-center bg-slate-50/30 border-t border-slate-100">
          <p className="text-sm text-slate-500">Showing <span className="font-bold text-slate-900">1 - 4</span> of <span className="font-bold text-slate-900">29</span> Hotels</p>
          <div className="flex items-center gap-1">
            <button className="p-2 rounded-lg text-slate-400 hover:bg-slate-100 transition-all"><ChevronRight size={18} className="rotate-180" /></button>
            <button className="w-8 h-8 rounded-lg bg-[#904d00] text-white font-bold text-sm">1</button>
            <button className="w-8 h-8 rounded-lg text-slate-900 hover:bg-slate-100 font-medium text-sm transition-all">2</button>
            <button className="w-8 h-8 rounded-lg text-slate-900 hover:bg-slate-100 font-medium text-sm transition-all">3</button>
            <span className="px-2 text-slate-400">...</span>
            <button className="w-8 h-8 rounded-lg text-slate-900 hover:bg-slate-100 font-medium text-sm transition-all">6</button>
            <button className="p-2 rounded-lg text-slate-400 hover:bg-slate-100 transition-all"><ChevronRight size={18} /></button>
          </div>
        </div>
      </div>
    </div>
  );
};

const AddHotelView = ({ onCancel, onSave }: { onCancel: () => void, onSave: () => void }) => {
  return (
    <div className="space-y-8 animate-in slide-in-from-right-4 duration-500 pb-24">
      <header>
        <div className="flex items-center gap-2 text-sm text-slate-500 mb-2">
          <span>Hotel Management</span>
          <ChevronRight size={14} />
          <span className="font-medium text-[#904d00]">Add New Property</span>
        </div>
        <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight font-headline">New Property Registration</h1>
        <p className="text-slate-500 mt-2 max-w-2xl">Enter the comprehensive details for the new asset in the Muong Thanh Luxury portfolio. Ensure all mandatory fields are accurate for reporting and analytics.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <section className="bg-slate-50 rounded-xl p-8 transition-all hover:shadow-sm">
            <div className="flex items-start gap-6">
              <div className="bg-[#904d00]/10 p-3 rounded-lg text-[#904d00]">
                <Hotel size={24} />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-slate-900 mb-6 font-headline">1. Basic Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                  <div className="col-span-2">
                    <label className="block text-sm font-semibold text-slate-900 mb-2">Property Name</label>
                    <input className="w-full bg-white border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#ffdcc3] outline-none text-slate-900 transition-all" placeholder="e.g. Muong Thanh Luxury Da Nang" type="text" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-900 mb-2">Property Type</label>
                    <select className="w-full bg-white border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#ffdcc3] outline-none text-slate-900 appearance-none">
                      <option>Hotel</option>
                      <option>Resort</option>
                      <option>Boutique</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-900 mb-2">Brand Tier</label>
                    <select className="w-full bg-white border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#ffdcc3] outline-none text-slate-900 appearance-none">
                      <option>Luxury</option>
                      <option>Grand</option>
                      <option>Holiday</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-slate-50 rounded-xl p-8 transition-all hover:shadow-sm">
            <div className="flex items-start gap-6">
              <div className="bg-blue-50 p-3 rounded-lg text-blue-600">
                <MapPin size={24} />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-slate-900 mb-6 font-headline">2. Location & Contact</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-slate-900 mb-2">City / Region</label>
                    <select className="w-full bg-white border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#ffdcc3] outline-none text-slate-900 appearance-none">
                      <option>Da Nang</option>
                      <option>Hanoi</option>
                      <option>Ho Chi Minh City</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-900 mb-2">Phone Number</label>
                    <input className="w-full bg-white border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#ffdcc3] outline-none text-slate-900 transition-all" placeholder="+84 236 3956 789" type="tel" />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-sm font-semibold text-slate-900 mb-2">Detailed Address</label>
                    <input className="w-full bg-white border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#ffdcc3] outline-none text-slate-900 transition-all" placeholder="Street name, District, Building number" type="text" />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-sm font-semibold text-slate-900 mb-2">Property Email</label>
                    <input className="w-full bg-white border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#ffdcc3] outline-none text-slate-900 transition-all" placeholder="management@muongthanh.com" type="email" />
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-slate-50 rounded-xl p-8 transition-all hover:shadow-sm">
            <div className="flex items-start gap-6">
              <div className="bg-emerald-50 p-3 rounded-lg text-emerald-600">
                <Star size={24} />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-slate-900 mb-6 font-headline">3. Amenities & Services</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {[
                    { label: 'Free Wi-Fi', icon: Wifi },
                    { label: 'Swimming Pool', icon: Bed },
                    { label: 'Fitness Center', icon: Dumbbell },
                    { label: 'Spa & Wellness', icon: Flower2 },
                    { label: 'Restaurant', icon: Utensils },
                    { label: 'Free Parking', icon: Car },
                  ].map((amenity) => (
                    <label key={amenity.label} className="flex items-center gap-3 p-4 bg-white rounded-xl cursor-pointer hover:bg-orange-50 transition-all group border-2 border-transparent has-[:checked]:border-[#904d00]">
                      <input type="checkbox" className="w-5 h-5 rounded border-slate-300 text-[#904d00] focus:ring-[#ffdcc3]" />
                      <span className="text-sm font-bold text-slate-700">{amenity.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </section>
        </div>

        <div className="space-y-8">
          <section className="bg-white rounded-xl p-8 shadow-sm border border-slate-100">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500">
                <CloudUpload size={20} />
              </div>
              <h2 className="text-lg font-bold font-headline">Branch Media</h2>
            </div>
            <div className="space-y-4">
              <div className="aspect-video w-full rounded-xl border-2 border-dashed border-slate-200 bg-slate-50 flex flex-col items-center justify-center p-6 text-center group cursor-pointer hover:bg-slate-100 transition-all">
                <div className="w-12 h-12 rounded-full bg-white shadow-sm flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <CloudUpload className="text-[#904d00]" size={24} />
                </div>
                <p className="text-sm font-bold text-slate-900 mb-1">Upload Main Branch Image</p>
                <p className="text-xs text-slate-500">Drag and drop or click to browse. Min size: 1920x1080px.</p>
              </div>
            </div>
          </section>

          <div className="bg-blue-600 p-6 rounded-xl text-white shadow-xl">
            <Info size={32} className="mb-4" />
            <h3 className="font-bold font-headline mb-2">Need Help?</h3>
            <p className="text-xs opacity-80 leading-relaxed">Ensure the Branch Code follows the global Muong Thanh naming convention (MTL-CITY-SEQ) to maintain analytics consistency.</p>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-64 right-0 p-6 bg-white/60 backdrop-blur-xl flex items-center justify-end gap-4 border-t border-slate-200/50">
        <button 
          onClick={onCancel}
          className="px-8 py-3 rounded-full border border-slate-200 text-slate-500 font-semibold text-sm hover:bg-slate-50 transition-all active:scale-95"
        >
          Cancel
        </button>
        <button 
          onClick={onSave}
          className="px-8 py-3 rounded-full bg-gradient-to-br from-[#904d00] to-[#ff8c00] text-white font-bold text-sm shadow-lg shadow-orange-500/20 hover:shadow-xl transition-all active:scale-95 flex items-center gap-2"
        >
          <CheckCircle2 size={18} />
          Save & Create Property
        </button>
      </div>
    </div>
  );
};

const BookingManagementView = () => {
  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end">
        <div className="space-y-1">
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight font-headline">Booking Management</h1>
          <p className="text-slate-500 text-sm">Monitor and manage all guest reservations across the network.</p>
        </div>
        <div className="flex gap-3">
          <button className="bg-white text-slate-700 px-5 py-2.5 rounded-full font-bold border border-slate-200 shadow-sm hover:bg-slate-50 transition-all flex items-center gap-2">
            <Download size={18} />
            Export CSV
          </button>
          <button className="bg-[#904d00] text-white px-6 py-2.5 rounded-full font-bold shadow-md hover:scale-[1.02] active:scale-95 transition-all flex items-center gap-2">
            <Plus size={18} />
            Manual Booking
          </button>
        </div>
      </div>

      <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-3 px-4 py-2 bg-slate-50 rounded-xl flex-1 min-w-[200px]">
          <Hotel size={16} className="text-slate-400" />
          <select className="bg-transparent border-none text-sm font-medium focus:ring-0 p-0 w-full">
            <option>All Hotels</option>
            <option>Muong Thanh Luxury Da Nang</option>
            <option>Muong Thanh Luxury Saigon</option>
          </select>
        </div>
        <div className="flex items-center gap-3 px-4 py-2 bg-slate-50 rounded-xl flex-1 min-w-[200px]">
          <RefreshCw size={16} className="text-slate-400" />
          <select className="bg-transparent border-none text-sm font-medium focus:ring-0 p-0 w-full">
            <option>All Status</option>
            <option>Confirmed</option>
            <option>Checked In</option>
            <option>Checked Out</option>
            <option>Cancelled</option>
          </select>
        </div>
        <div className="flex items-center gap-3 px-4 py-2 bg-slate-50 rounded-xl flex-1 min-w-[200px]">
          <Calendar size={16} className="text-slate-400" />
          <input type="text" placeholder="Select Date Range" className="bg-transparent border-none text-sm font-medium focus:ring-0 p-0 w-full" />
        </div>
        <button className="p-3 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition-all">
          <Filter size={20} />
        </button>
      </div>

      <div className="bg-white rounded-3xl shadow-sm overflow-hidden border border-slate-100">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500">Booking ID</th>
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500">Customer</th>
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500">Hotel</th>
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500">Room Type</th>
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500">Dates</th>
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500">Status</th>
                <th className="px-6 py-5 text-[11px] font-bold uppercase tracking-widest text-slate-500 text-right">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[
                { id: 'BK-9901', customer: 'Nguyen Van A', hotel: 'MT Da Nang', room: 'Deluxe Sea View', dates: '22/03 - 25/03', status: 'Confirmed', total: '$450', color: 'blue' },
                { id: 'BK-9902', customer: 'Tran Thi B', hotel: 'MT Saigon', room: 'Executive Suite', dates: '23/03 - 24/03', status: 'Checked In', total: '$280', color: 'emerald' },
                { id: 'BK-9903', customer: 'Le Van C', hotel: 'MT Hanoi', room: 'Superior Twin', dates: '25/03 - 28/03', status: 'Pending', total: '$360', color: 'slate' },
                { id: 'BK-9904', customer: 'Pham Thi D', hotel: 'MT Da Nang', room: 'Presidential Suite', dates: '22/03 - 27/03', status: 'Cancelled', total: '$1,200', color: 'red' },
              ].map((bk, i) => (
                <tr key={i} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-6 py-5 font-mono text-xs text-[#435b9f] font-bold">{bk.id}</td>
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 text-[10px] font-bold">
                        <User size={14} />
                      </div>
                      <span className="text-sm font-bold text-slate-900">{bk.customer}</span>
                    </div>
                  </td>
                  <td className="px-6 py-5 text-sm text-slate-600 font-medium">{bk.hotel}</td>
                  <td className="px-6 py-5 text-sm text-slate-500">{bk.room}</td>
                  <td className="px-6 py-5 text-sm text-slate-500">{bk.dates}</td>
                  <td className="px-6 py-5">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase bg-${bk.color}-50 text-${bk.color}-700`}>{bk.status}</span>
                  </td>
                  <td className="px-6 py-5 text-right font-bold text-slate-900">{bk.total}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const CustomerManagementView = () => {
  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end">
        <div className="space-y-1">
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight font-headline">Customer Management</h1>
          <p className="text-slate-500 text-sm">Manage guest profiles, loyalty status, and historical preferences.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
          <h3 className="text-xl font-bold text-slate-900 mb-8 font-headline flex items-center gap-3">
            <UserPlus className="text-[#904d00]" size={24} />
            Add New Customer
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-600">Full Name</label>
              <input className="w-full px-5 py-3.5 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-[#ffdcc3] outline-none transition-all" placeholder="Enter guest name" type="text" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-600">Email Address</label>
              <input className="w-full px-5 py-3.5 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-[#ffdcc3] outline-none transition-all" placeholder="guest@example.com" type="email" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-600">Phone Number</label>
              <input className="w-full px-5 py-3.5 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-[#ffdcc3] outline-none transition-all" placeholder="+84 ..." type="tel" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-600">ID / Passport Number</label>
              <input className="w-full px-5 py-3.5 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-[#ffdcc3] outline-none transition-all" placeholder="Document ID" type="text" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-600">Gender</label>
              <div className="flex gap-4">
                {['Male', 'Female', 'Other'].map(g => (
                  <label key={g} className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-slate-50 rounded-xl cursor-pointer hover:bg-slate-100 transition-all border-2 border-transparent has-[:checked]:border-[#904d00] has-[:checked]:bg-orange-50">
                    <input type="radio" name="gender" className="hidden" />
                    <span className="text-sm font-bold text-slate-700">{g}</span>
                  </label>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-600">Date of Birth</label>
              <input className="w-full px-5 py-3.5 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-[#ffdcc3] outline-none transition-all" type="date" />
            </div>
            <div className="col-span-2 space-y-2">
              <label className="text-sm font-bold text-slate-600">Residential Address</label>
              <textarea className="w-full px-5 py-3.5 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-[#ffdcc3] outline-none transition-all h-24 resize-none" placeholder="Street, City, Country"></textarea>
            </div>
          </div>
          <div className="mt-10 flex justify-end gap-4">
            <button className="px-8 py-3.5 text-slate-500 font-bold hover:text-slate-900 transition-colors">Clear Form</button>
            <button className="px-10 py-3.5 bg-[#904d00] text-white font-bold rounded-full shadow-lg hover:scale-[1.02] active:scale-95 transition-all">Create Profile</button>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
            <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
              <History size={20} className="text-slate-400" />
              Recent Activity
            </h3>
            <div className="space-y-6">
              {[
                { user: 'Nguyen Van A', action: 'Booked Deluxe Room', time: '2 mins ago', icon: CalendarDays, color: 'blue' },
                { user: 'Tran Thi B', action: 'Updated Profile', time: '1 hour ago', icon: User, color: 'orange' },
                { user: 'Le Van C', action: 'Cancelled MT-8842', time: '3 hours ago', icon: Trash2, color: 'red' },
              ].map((act, i) => (
                <div key={i} className="flex gap-4">
                  <div className={`w-10 h-10 rounded-xl bg-${act.color}-50 text-${act.color}-600 flex items-center justify-center shrink-0`}>
                    <act.icon size={18} />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-900">{act.user}</p>
                    <p className="text-xs text-slate-500">{act.action}</p>
                    <p className="text-[10px] text-slate-400 mt-1 font-bold uppercase tracking-tighter">{act.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-8 rounded-3xl text-white shadow-xl relative overflow-hidden">
            <div className="relative z-10">
              <Star className="text-orange-400 mb-4 fill-current" size={32} />
              <h3 className="text-xl font-bold font-headline mb-2">Loyalty Program</h3>
              <p className="text-sm opacity-70 mb-6 leading-relaxed">Muong Thanh Luxury members enjoy exclusive benefits and priority booking across all branches.</p>
              <button className="w-full py-3 bg-white/10 hover:bg-white/20 rounded-xl font-bold text-sm transition-all backdrop-blur-sm">View Member Tiers</button>
            </div>
            <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-orange-500/10 rounded-full blur-3xl"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

const SettingsView = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="mb-10">
        <h2 className="text-3xl font-extrabold tracking-tight text-slate-900 mb-2">System Settings</h2>
        <p className="text-slate-500 font-medium">Manage your administrative profile and global system preferences.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-3 space-y-2">
          {[
            { id: 'profile', label: 'General Profile', icon: Users, active: true },
            { id: 'security', label: 'Security', icon: Shield },
            { id: 'notifications', label: 'Notifications', icon: BellRing },
            { id: 'system', label: 'System Configuration', icon: Settings2 },
          ].map((item) => (
            <button
              key={item.id}
              className={`w-full flex items-center gap-3 px-5 py-4 rounded-xl transition-all ${
                item.active 
                  ? 'bg-white shadow-sm border-l-4 border-[#904d00] text-[#904d00] font-bold' 
                  : 'hover:bg-slate-100 text-slate-500 font-medium'
              }`}
            >
              <item.icon size={18} />
              <span>{item.label}</span>
            </button>
          ))}
          <div className="mt-12 p-6 rounded-2xl bg-blue-50 border border-blue-100">
            <Activity size={20} className="text-blue-600 mb-3" />
            <p className="text-xs font-bold text-blue-600 uppercase tracking-widest mb-1">System Health</p>
            <p className="text-sm text-blue-900 mb-4 leading-relaxed">All modules are currently operational. Next backup in 4 hours.</p>
            <div className="w-full bg-white/50 h-1.5 rounded-full overflow-hidden">
              <div className="bg-blue-600 h-full w-[88%]"></div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-9 space-y-8">
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
            <h3 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <span className="w-1.5 h-6 bg-[#904d00] rounded-full"></span>
              Profile Information
            </h3>
            <div className="space-y-8">
              <div className="flex items-center gap-8 p-6 rounded-2xl bg-slate-50/50">
                <div className="relative group">
                  <img 
                    className="w-24 h-24 rounded-2xl object-cover ring-4 ring-white shadow-md" 
                    src="https://picsum.photos/seed/admin/200/200" 
                    alt="Admin Profile" 
                  />
                  <button className="absolute -bottom-2 -right-2 bg-[#904d00] text-white p-2 rounded-xl shadow-lg hover:scale-105 transition-transform">
                    <Edit size={14} />
                  </button>
                </div>
                <div className="flex-1">
                  <h4 className="font-bold text-slate-900">Admin Profile Picture</h4>
                  <p className="text-sm text-slate-500 mb-4">PNG, JPG or GIF. Max size of 1MB.</p>
                  <div className="flex gap-3">
                    <button className="px-4 py-2 bg-[#ffdcc3] text-[#2f1500] text-xs font-bold rounded-lg hover:bg-[#904d00] hover:text-white transition-colors">Upload New</button>
                    <button className="px-4 py-2 text-red-600 text-xs font-bold rounded-lg hover:bg-red-50 transition-colors">Remove</button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-500 flex items-center gap-2">
                    Admin Name
                    <Star size={10} className="text-[#904d00] fill-current" />
                  </label>
                  <input className="w-full px-5 py-3.5 bg-slate-100 border-none rounded-xl text-slate-900 focus:ring-2 focus:ring-[#ffdcc3] outline-none transition-all" type="text" defaultValue="Nguyen Admin" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-500">Email Address</label>
                  <input className="w-full px-5 py-3.5 bg-slate-100 border-none rounded-xl text-slate-900 focus:ring-2 focus:ring-[#ffdcc3] outline-none transition-all" type="email" defaultValue="admin@muongthanh.luxury" />
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-4">
            <button className="px-8 py-3.5 text-slate-500 font-bold hover:text-slate-900 transition-colors">Discard Changes</button>
            <button className="px-10 py-3.5 bg-gradient-to-br from-[#904d00] to-[#ff8c00] text-white font-bold rounded-full shadow-lg shadow-orange-500/20 hover:scale-[1.02] active:scale-95 transition-all">Save Changes</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [currentView, setView] = React.useState<View>('dashboard');
  const [showToast, setShowToast] = React.useState(false);

  const handleAddHotel = () => {
    setView('add-hotel');
  };

  const handleCancelAdd = () => {
    setView('hotels');
  };

  const handleSaveHotel = () => {
    setShowToast(true);
    setView('hotels');
    setTimeout(() => setShowToast(false), 5000);
  };

  return (
    <div className="bg-[#f8f9fa] text-[#191c1d] min-h-screen flex font-body selection:bg-[#ffdcc3] selection:text-[#2f1500]">
      <Sidebar currentView={currentView === 'add-hotel' ? 'hotels' : currentView} setView={setView} />
      
      <div className="flex-1 ml-64 flex flex-col">
        <Topbar 
          title={currentView.charAt(0).toUpperCase() + currentView.slice(1).replace('-', ' ')} 
          breadcrumbs={currentView === 'add-hotel' ? ['Hotel Management', 'Add New Property'] : undefined}
        />
        
        <main className="p-8 flex-1 max-w-[1600px] mx-auto w-full">
          <AnimatePresence mode="wait">
            {currentView === 'dashboard' && (
              <motion.div key="dashboard" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <DashboardView />
              </motion.div>
            )}
            {currentView === 'hotels' && (
              <motion.div key="hotels" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <HotelManagementView onAdd={handleAddHotel} />
              </motion.div>
            )}
            {currentView === 'add-hotel' && (
              <motion.div key="add-hotel" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <AddHotelView onCancel={handleCancelAdd} onSave={handleSaveHotel} />
              </motion.div>
            )}
            {currentView === 'bookings' && (
              <motion.div key="bookings" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <BookingManagementView />
              </motion.div>
            )}
            {currentView === 'customers' && (
              <motion.div key="customers" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <CustomerManagementView />
              </motion.div>
            )}
            {currentView === 'settings' && (
              <motion.div key="settings" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <SettingsView />
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        <footer className="p-8 pt-0 mt-auto">
          <div className="h-px w-full bg-slate-200/50 mb-6"></div>
          <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold tracking-widest uppercase">
            <span>Muong Thanh Management Portal © 2026</span>
            <div className="flex gap-4">
              <a href="#" className="hover:text-[#904d00] transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-[#904d00] transition-colors">Terms of Service</a>
            </div>
          </div>
        </footer>
      </div>

      {/* Success Toast */}
      <AnimatePresence>
        {showToast && (
          <motion.div 
            initial={{ x: 100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 100, opacity: 0 }}
            className="fixed top-6 right-6 z-[100]"
          >
            <div className="bg-white border border-emerald-100 shadow-2xl rounded-2xl p-4 flex items-center gap-4 min-w-[320px]">
              <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
                <CheckCircle2 size={20} />
              </div>
              <div className="flex-1">
                <h4 className="text-sm font-bold text-slate-900">Property Created Successfully</h4>
                <p className="text-xs text-slate-500">Muong Thanh Luxury Da Nang is now active.</p>
              </div>
              <button onClick={() => setShowToast(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X size={16} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
