export type StaffRole = 'Manager' | 'Receptionist' | 'Housekeeping' | 'Security' | 'Chef';

export interface Staff {
  id: string;
  name: string;
  role: StaffRole;
  email: string;
  phone: string;
  avatar?: string;
  status: 'Active' | 'On Leave' | 'Inactive';
}

export type RoomType = 'Standard' | 'Deluxe' | 'Suite' | 'Penthouse';

export interface Room {
  id: string;
  number: string;
  type: RoomType;
  price: number;
  status: 'Available' | 'Occupied' | 'Cleaning' | 'Maintenance';
  image?: string;
}

export interface Booking {
  id: string;
  customerName: string;
  roomNumber: string;
  checkIn: string;
  checkOut: string;
  status: 'Confirmed' | 'Checked In' | 'Checked Out' | 'Cancelled';
  totalPrice: number;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  totalBookings: number;
  lastStay: string;
}
