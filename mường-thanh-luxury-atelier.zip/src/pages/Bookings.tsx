import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Calendar, 
  User,
  X,
  Bed,
  CreditCard,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Booking } from '../types';

const BookingsPage: React.FC = () => {
  const [showForm, setShowForm] = useState(false);
  const [bookings, setBookings] = useState<Booking[]>([
    { id: '1', customerName: 'Nguyen Van A', roomNumber: '101', checkIn: '2026-03-22', checkOut: '2026-03-25', status: 'Checked In', totalPrice: 360 },
    { id: '2', customerName: 'Tran Thi B', roomNumber: '201', checkIn: '2026-03-23', checkOut: '2026-03-26', status: 'Confirmed', totalPrice: 750 },
    { id: '3', customerName: 'Le Van C', roomNumber: '301', checkIn: '2026-03-20', checkOut: '2026-03-22', status: 'Checked Out', totalPrice: 900 },
    { id: '4', customerName: 'Pham Thi D', roomNumber: '102', checkIn: '2026-03-24', checkOut: '2026-03-25', status: 'Cancelled', totalPrice: 120 },
  ]);

  const [newBooking, setNewBooking] = useState<Partial<Booking>>({
    customerName: '',
    roomNumber: '',
    checkIn: '',
    checkOut: '',
    status: 'Confirmed'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const booking: Booking = {
      id: Math.random().toString(36).substr(2, 9),
      customerName: newBooking.customerName || 'Unknown',
      roomNumber: newBooking.roomNumber || '000',
      checkIn: newBooking.checkIn || '',
      checkOut: newBooking.checkOut || '',
      status: newBooking.status as any || 'Confirmed',
      totalPrice: 0 // In a real app, calculate this
    };
    setBookings([booking, ...bookings]);
    setShowForm(false);
    setNewBooking({ customerName: '', roomNumber: '', checkIn: '', checkOut: '', status: 'Confirmed' });
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-extrabold tracking-tight mb-2">Bookings</h1>
          <p className="text-tertiary font-medium">Manage guest reservations and check-in/out processes.</p>
        </div>
        <button 
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-6 py-3.5 rounded-2xl font-bold text-white primary-gradient shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
        >
          <Plus size={20} />
          Create New Booking
        </button>
      </div>

      <div className="card-container">
        <div className="flex flex-wrap gap-4 justify-between items-center mb-8">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
            <input 
              type="text" 
              placeholder="Search bookings by guest or room..." 
              className="w-full bg-surface-container border-none rounded-2xl py-3 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
            />
          </div>
          <div className="flex gap-3">
            <button className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-surface-container text-sm font-bold text-tertiary hover:bg-surface-container-high transition-colors">
              <Filter size={18} />
              Filter
            </button>
          </div>
        </div>

        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left border-separate border-spacing-y-4">
            <thead>
              <tr className="text-xs font-bold text-tertiary uppercase tracking-wider">
                <th className="px-4 pb-2">Guest</th>
                <th className="px-4 pb-2">Room</th>
                <th className="px-4 pb-2">Stay Duration</th>
                <th className="px-4 pb-2">Status</th>
                <th className="px-4 pb-2">Total</th>
                <th className="px-4 pb-2 text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking) => (
                <tr key={booking.id} className="group hover:bg-surface-container-low transition-colors rounded-2xl">
                  <td className="px-4 py-4 first:rounded-l-2xl">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-surface-container flex items-center justify-center text-secondary font-bold shadow-sm">
                        {booking.customerName.split(' ').map(n => n[0]).join('')}
                      </div>
                      <span className="text-sm font-bold">{booking.customerName}</span>
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-2 text-sm font-bold text-tertiary">
                      <Bed size={16} className="text-primary" />
                      Room {booking.roomNumber}
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-2 text-xs text-tertiary font-medium">
                      <Calendar size={14} />
                      {booking.checkIn} → {booking.checkOut}
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      booking.status === 'Checked In' ? 'bg-emerald-100 text-emerald-700' :
                      booking.status === 'Confirmed' ? 'bg-blue-100 text-blue-700' :
                      booking.status === 'Checked Out' ? 'bg-amber-100 text-amber-700' :
                      'bg-error/10 text-error'
                    }`}>
                      {booking.status}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <span className="text-sm font-extrabold text-primary">${booking.totalPrice}</span>
                  </td>
                  <td className="px-4 py-4 last:rounded-r-2xl text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button className="p-2 rounded-xl hover:bg-surface-container transition-colors">
                        <MoreHorizontal size={18} className="text-tertiary" />
                      </button>
                      <button className="p-2 rounded-xl hover:bg-surface-container text-primary transition-colors">
                        <ChevronRight size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {showForm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowForm(false)}
              className="absolute inset-0 bg-on-surface/20 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, x: 100 }}
              animate={{ scale: 1, opacity: 1, x: 0 }}
              exit={{ scale: 0.95, opacity: 0, x: 100 }}
              className="relative w-full max-w-2xl bg-surface-container-lowest rounded-[40px] p-10 shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto no-scrollbar"
            >
              <div className="absolute top-0 left-0 w-full h-2 primary-gradient" />
              
              <div className="flex justify-between items-center mb-10">
                <div>
                  <h2 className="text-3xl font-extrabold tracking-tight">Create New Booking</h2>
                  <p className="text-tertiary font-medium">Record a new guest reservation.</p>
                </div>
                <button 
                  onClick={() => setShowForm(false)}
                  className="p-3 rounded-2xl hover:bg-surface-container transition-colors"
                >
                  <X size={24} className="text-tertiary" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2 md:col-span-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Guest Name</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
                      <input 
                        required
                        type="text" 
                        value={newBooking.customerName}
                        onChange={(e) => setNewBooking({...newBooking, customerName: e.target.value})}
                        placeholder="Guest Full Name"
                        className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Room Number</label>
                    <div className="relative">
                      <Bed className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
                      <input 
                        required
                        type="text" 
                        value={newBooking.roomNumber}
                        onChange={(e) => setNewBooking({...newBooking, roomNumber: e.target.value})}
                        placeholder="e.g. 101"
                        className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Initial Status</label>
                    <select 
                      value={newBooking.status}
                      onChange={(e) => setNewBooking({...newBooking, status: e.target.value as any})}
                      className="w-full bg-surface-container-low border-none rounded-2xl py-4 px-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all appearance-none"
                    >
                      <option value="Confirmed">Confirmed</option>
                      <option value="Checked In">Checked In</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Check-In Date</label>
                    <div className="relative">
                      <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
                      <input 
                        required
                        type="date" 
                        value={newBooking.checkIn}
                        onChange={(e) => setNewBooking({...newBooking, checkIn: e.target.value})}
                        className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Check-Out Date</label>
                    <div className="relative">
                      <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
                      <input 
                        required
                        type="date" 
                        value={newBooking.checkOut}
                        onChange={(e) => setNewBooking({...newBooking, checkOut: e.target.value})}
                        className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                      />
                    </div>
                  </div>
                </div>

                <div className="p-6 rounded-3xl bg-surface-container-low flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-surface-container-lowest flex items-center justify-center text-primary">
                      <CreditCard size={24} />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-tertiary uppercase tracking-widest">Estimated Total</p>
                      <p className="text-2xl font-extrabold text-primary">$0.00</p>
                    </div>
                  </div>
                  <p className="text-[10px] font-bold text-tertiary uppercase tracking-widest text-right">Payment due<br/>at check-in</p>
                </div>

                <div className="flex gap-4 pt-6">
                  <button 
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="flex-1 py-4 rounded-2xl font-bold text-tertiary hover:bg-surface-container transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 py-4 rounded-2xl font-bold text-white primary-gradient shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
                  >
                    Confirm Booking
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default BookingsPage;
