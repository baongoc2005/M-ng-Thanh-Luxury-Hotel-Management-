import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Mail, 
  Phone, 
  ChevronRight,
  X,
  Upload,
  User
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Staff, StaffRole } from '../types';

const StaffPage: React.FC = () => {
  const [showForm, setShowForm] = useState(false);
  const [staffList, setStaffList] = useState<Staff[]>([
    { id: '1', name: 'Nguyen Van A', role: 'Manager', email: 'a.nguyen@muongthanh.com', phone: '0901234567', status: 'Active' },
    { id: '2', name: 'Tran Thi B', role: 'Receptionist', email: 'b.tran@muongthanh.com', phone: '0907654321', status: 'Active' },
    { id: '3', name: 'Le Van C', role: 'Housekeeping', email: 'c.le@muongthanh.com', phone: '0901112223', status: 'On Leave' },
    { id: '4', name: 'Pham Thi D', role: 'Chef', email: 'd.pham@muongthanh.com', phone: '0903334445', status: 'Active' },
  ]);

  const [newStaff, setNewStaff] = useState<Partial<Staff>>({
    name: '',
    role: 'Receptionist',
    email: '',
    phone: '',
    status: 'Active'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const staff: Staff = {
      id: Math.random().toString(36).substr(2, 9),
      name: newStaff.name || 'Unknown',
      role: newStaff.role as StaffRole,
      email: newStaff.email || '',
      phone: newStaff.phone || '',
      status: newStaff.status as any || 'Active'
    };
    setStaffList([staff, ...staffList]);
    setShowForm(false);
    setNewStaff({ name: '', role: 'Receptionist', email: '', phone: '', status: 'Active' });
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-extrabold tracking-tight mb-2">Staff Management</h1>
          <p className="text-tertiary font-medium">Manage your hotel's professional team and their profiles.</p>
        </div>
        <button 
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-6 py-3.5 rounded-2xl font-bold text-white primary-gradient shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
        >
          <Plus size={20} />
          Create New Profile
        </button>
      </div>

      <div className="card-container">
        <div className="flex flex-wrap gap-4 justify-between items-center mb-8">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
            <input 
              type="text" 
              placeholder="Search staff by name, role, or email..." 
              className="w-full bg-surface-container border-none rounded-2xl py-3 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
            />
          </div>
          <div className="flex gap-3">
            <button className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-surface-container text-sm font-bold text-tertiary hover:bg-surface-container-high transition-colors">
              <Filter size={18} />
              Filter
            </button>
            <button className="px-4 py-3 rounded-2xl bg-surface-container text-sm font-bold text-tertiary hover:bg-surface-container-high transition-colors">
              Export CSV
            </button>
          </div>
        </div>

        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left border-separate border-spacing-y-4">
            <thead>
              <tr className="text-xs font-bold text-tertiary uppercase tracking-wider">
                <th className="px-4 pb-2">Staff Member</th>
                <th className="px-4 pb-2">Role</th>
                <th className="px-4 pb-2">Contact</th>
                <th className="px-4 pb-2">Status</th>
                <th className="px-4 pb-2 text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {staffList.map((staff) => (
                <tr key={staff.id} className="group hover:bg-surface-container-low transition-colors rounded-2xl">
                  <td className="px-4 py-4 first:rounded-l-2xl">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-surface-container flex items-center justify-center text-primary font-bold shadow-sm">
                        {staff.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <p className="text-sm font-bold">{staff.name}</p>
                        <p className="text-xs text-tertiary font-medium">ID: {staff.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <span className="text-sm font-bold text-secondary">{staff.role}</span>
                  </td>
                  <td className="px-4 py-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-tertiary font-medium">
                        <Mail size={12} />
                        {staff.email}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-tertiary font-medium">
                        <Phone size={12} />
                        {staff.phone}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      staff.status === 'Active' ? 'bg-emerald-100 text-emerald-700' :
                      staff.status === 'On Leave' ? 'bg-amber-100 text-amber-700' :
                      'bg-error/10 text-error'
                    }`}>
                      {staff.status}
                    </span>
                  </td>
                  <td className="px-4 py-4 last:rounded-r-2xl text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button className="p-2 rounded-xl hover:bg-surface-container transition-colors">
                        <MoreHorizontal size={18} className="text-tertiary" />
                      </button>
                      <button className="p-2 rounded-xl hover:bg-surface-container text-primary transition-colors">
                        <ChevronRight size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {showForm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowForm(false)}
              className="absolute inset-0 bg-on-surface/20 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, x: 100 }}
              animate={{ scale: 1, opacity: 1, x: 0 }}
              exit={{ scale: 0.95, opacity: 0, x: 100 }}
              className="relative w-full max-w-2xl bg-surface-container-lowest rounded-[40px] p-10 shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto no-scrollbar"
            >
              <div className="absolute top-0 left-0 w-full h-2 primary-gradient" />
              
              <div className="flex justify-between items-center mb-10">
                <div>
                  <h2 className="text-3xl font-extrabold tracking-tight">Create New Profile</h2>
                  <p className="text-tertiary font-medium">Enter the details for the new staff member.</p>
                </div>
                <button 
                  onClick={() => setShowForm(false)}
                  className="p-3 rounded-2xl hover:bg-surface-container transition-colors"
                >
                  <X size={24} className="text-tertiary" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="flex flex-col items-center gap-4 mb-8">
                  <div className="w-32 h-32 rounded-[40px] bg-surface-container flex flex-col items-center justify-center text-tertiary border-2 border-dashed border-outline-variant group cursor-pointer hover:bg-surface-container-high transition-all">
                    <Upload size={32} className="mb-2 group-hover:-translate-y-1 transition-transform" />
                    <span className="text-[10px] font-bold uppercase tracking-widest">Upload Photo</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
                      <input 
                        required
                        type="text" 
                        value={newStaff.name}
                        onChange={(e) => setNewStaff({...newStaff, name: e.target.value})}
                        placeholder="e.g. Nguyen Van A"
                        className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Role</label>
                    <select 
                      value={newStaff.role}
                      onChange={(e) => setNewStaff({...newStaff, role: e.target.value as StaffRole})}
                      className="w-full bg-surface-container-low border-none rounded-2xl py-4 px-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all appearance-none"
                    >
                      <option value="Manager">Manager</option>
                      <option value="Receptionist">Receptionist</option>
                      <option value="Housekeeping">Housekeeping</option>
                      <option value="Security">Security</option>
                      <option value="Chef">Chef</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
                      <input 
                        required
                        type="email" 
                        value={newStaff.email}
                        onChange={(e) => setNewStaff({...newStaff, email: e.target.value})}
                        placeholder="a.nguyen@muongthanh.com"
                        className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Phone Number</label>
                    <div className="relative">
                      <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
                      <input 
                        required
                        type="tel" 
                        value={newStaff.phone}
                        onChange={(e) => setNewStaff({...newStaff, phone: e.target.value})}
                        placeholder="090 123 4567"
                        className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 pt-6">
                  <button 
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="flex-1 py-4 rounded-2xl font-bold text-tertiary hover:bg-surface-container transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 py-4 rounded-2xl font-bold text-white primary-gradient shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
                  >
                    Create Profile
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default StaffPage;
