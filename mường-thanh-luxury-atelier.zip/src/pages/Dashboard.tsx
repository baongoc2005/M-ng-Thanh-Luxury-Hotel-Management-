import React from 'react';
import { 
  TrendingUp, 
  Users, 
  BedDouble, 
  CalendarCheck, 
  ArrowUpRight, 
  ArrowDownRight,
  MoreHorizontal
} from 'lucide-react';
import { motion } from 'motion/react';

const StatCard: React.FC<{
  title: string;
  value: string;
  change: number;
  icon: React.ElementType;
  color: string;
}> = ({ title, value, change, icon: Icon, color }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="card-container flex-1 min-w-[240px]"
  >
    <div className="flex justify-between items-start mb-4">
      <div className={`w-12 h-12 rounded-2xl ${color} flex items-center justify-center text-white shadow-lg`}>
        <Icon size={24} />
      </div>
      <button className="p-2 rounded-xl hover:bg-surface-container transition-colors">
        <MoreHorizontal size={20} className="text-tertiary" />
      </button>
    </div>
    
    <h3 className="text-sm font-semibold text-tertiary mb-1">{title}</h3>
    <div className="flex items-end gap-3">
      <span className="text-3xl font-bold tracking-tight">{value}</span>
      <div className={`flex items-center gap-0.5 text-xs font-bold mb-1 ${change >= 0 ? 'text-emerald-600' : 'text-error'}`}>
        {change >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
        {Math.abs(change)}%
      </div>
    </div>
  </motion.div>
);

const Dashboard: React.FC = () => {
  const recentBookings = [
    { id: '1', customer: 'Nguyen Van A', room: '302', status: 'Checked In', date: '22 Mar, 2026' },
    { id: '2', customer: 'Tran Thi B', room: '105', status: 'Confirmed', date: '23 Mar, 2026' },
    { id: '3', customer: 'Le Van C', room: '408', status: 'Checked Out', date: '21 Mar, 2026' },
    { id: '4', customer: 'Pham Thi D', room: '210', status: 'Cancelled', date: '20 Mar, 2026' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-extrabold tracking-tight mb-2">Dashboard</h1>
          <p className="text-tertiary font-medium">Welcome back, here's what's happening today.</p>
        </div>
        <button className="px-6 py-3.5 rounded-2xl font-bold text-white primary-gradient shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all">
          Generate Report
        </button>
      </div>

      <div className="flex flex-wrap gap-6">
        <StatCard 
          title="Total Revenue" 
          value="$128,430" 
          change={12.5} 
          icon={TrendingUp} 
          color="bg-primary" 
        />
        <StatCard 
          title="Active Bookings" 
          value="48" 
          change={8.2} 
          icon={CalendarCheck} 
          color="bg-secondary" 
        />
        <StatCard 
          title="Room Occupancy" 
          value="84%" 
          change={-2.4} 
          icon={BedDouble} 
          color="bg-emerald-600" 
        />
        <StatCard 
          title="Total Customers" 
          value="1,240" 
          change={14.8} 
          icon={Users} 
          color="bg-amber-600" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-2 card-container"
        >
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-xl font-bold">Recent Bookings</h2>
            <button className="text-sm font-bold text-primary hover:underline">View All</button>
          </div>
          
          <div className="overflow-x-auto no-scrollbar">
            <table className="w-full text-left border-separate border-spacing-y-4">
              <thead>
                <tr className="text-xs font-bold text-tertiary uppercase tracking-wider">
                  <th className="px-4 pb-2">Customer</th>
                  <th className="px-4 pb-2">Room</th>
                  <th className="px-4 pb-2">Status</th>
                  <th className="px-4 pb-2">Date</th>
                  <th className="px-4 pb-2 text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {recentBookings.map((booking) => (
                  <tr key={booking.id} className="group hover:bg-surface-container-low transition-colors rounded-2xl">
                    <td className="px-4 py-4 first:rounded-l-2xl">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center text-xs font-bold text-tertiary">
                          {booking.customer.split(' ').map(n => n[0]).join('')}
                        </div>
                        <span className="text-sm font-bold">{booking.customer}</span>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <span className="text-sm font-medium text-tertiary">Room {booking.room}</span>
                    </td>
                    <td className="px-4 py-4">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        booking.status === 'Checked In' ? 'bg-emerald-100 text-emerald-700' :
                        booking.status === 'Confirmed' ? 'bg-blue-100 text-blue-700' :
                        booking.status === 'Checked Out' ? 'bg-amber-100 text-amber-700' :
                        'bg-error/10 text-error'
                      }`}>
                        {booking.status}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-sm text-tertiary font-medium">{booking.date}</td>
                    <td className="px-4 py-4 last:rounded-r-2xl text-right">
                      <button className="p-2 rounded-xl hover:bg-surface-container transition-colors">
                        <MoreHorizontal size={18} className="text-tertiary" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="card-container"
        >
          <h2 className="text-xl font-bold mb-8">Room Status</h2>
          <div className="space-y-6">
            {[
              { label: 'Available', count: 24, color: 'bg-emerald-500', total: 60 },
              { label: 'Occupied', count: 32, color: 'bg-blue-500', total: 60 },
              { label: 'Cleaning', count: 4, color: 'bg-amber-500', total: 60 },
            ].map((status) => (
              <div key={status.label} className="space-y-2">
                <div className="flex justify-between text-sm font-bold">
                  <span className="text-tertiary">{status.label}</span>
                  <span>{status.count} Rooms</span>
                </div>
                <div className="h-2 bg-surface-container rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${(status.count / status.total) * 100}%` }}
                    className={`h-full ${status.color}`}
                  />
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-12 p-6 rounded-3xl bg-primary/5 border-none">
            <h4 className="text-sm font-bold text-primary mb-2">Upgrade to Pro</h4>
            <p className="text-xs text-tertiary mb-4 leading-relaxed">Get advanced analytics and automated room scheduling features.</p>
            <button className="w-full py-3 rounded-xl bg-primary text-white text-xs font-bold hover:bg-primary/90 transition-colors">
              Learn More
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;
