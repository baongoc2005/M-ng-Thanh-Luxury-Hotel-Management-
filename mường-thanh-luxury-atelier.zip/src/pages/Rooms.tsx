import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Bed, 
  DollarSign,
  X,
  Upload,
  Layers
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Room, RoomType } from '../types';

const RoomsPage: React.FC = () => {
  const [showForm, setShowForm] = useState(false);
  const [rooms, setRooms] = useState<Room[]>([
    { id: '1', number: '101', type: 'Standard', price: 120, status: 'Available' },
    { id: '2', number: '102', type: 'Standard', price: 120, status: 'Occupied' },
    { id: '3', number: '201', type: 'Deluxe', price: 250, status: 'Cleaning' },
    { id: '4', number: '301', type: 'Suite', price: 450, status: 'Available' },
    { id: '5', number: '501', type: 'Penthouse', price: 1200, status: 'Maintenance' },
  ]);

  const [newRoom, setNewRoom] = useState<Partial<Room>>({
    number: '',
    type: 'Standard',
    price: 0,
    status: 'Available'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const room: Room = {
      id: Math.random().toString(36).substr(2, 9),
      number: newRoom.number || '000',
      type: newRoom.type as RoomType,
      price: Number(newRoom.price) || 0,
      status: newRoom.status as any || 'Available'
    };
    setRooms([room, ...rooms]);
    setShowForm(false);
    setNewRoom({ number: '', type: 'Standard', price: 0, status: 'Available' });
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-extrabold tracking-tight mb-2">Room Management</h1>
          <p className="text-tertiary font-medium">Configure and monitor all hotel rooms and their status.</p>
        </div>
        <button 
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-6 py-3.5 rounded-2xl font-bold text-white primary-gradient shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
        >
          <Plus size={20} />
          Create New Room
        </button>
      </div>

      <div className="card-container">
        <div className="flex flex-wrap gap-4 justify-between items-center mb-8">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
            <input 
              type="text" 
              placeholder="Search rooms by number or type..." 
              className="w-full bg-surface-container border-none rounded-2xl py-3 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
            />
          </div>
          <div className="flex gap-3">
            <button className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-surface-container text-sm font-bold text-tertiary hover:bg-surface-container-high transition-colors">
              <Filter size={18} />
              Filter
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {rooms.map((room) => (
            <motion.div 
              key={room.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-surface-container-low rounded-[32px] p-6 hover:bg-surface-container transition-all group"
            >
              <div className="flex justify-between items-start mb-6">
                <div className="w-14 h-14 rounded-2xl bg-surface-container-lowest flex items-center justify-center text-primary shadow-sm group-hover:scale-110 transition-transform">
                  <Bed size={28} />
                </div>
                <div className="flex flex-col items-end gap-2">
                  <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    room.status === 'Available' ? 'bg-emerald-100 text-emerald-700' :
                    room.status === 'Occupied' ? 'bg-blue-100 text-blue-700' :
                    room.status === 'Cleaning' ? 'bg-amber-100 text-amber-700' :
                    'bg-error/10 text-error'
                  }`}>
                    {room.status}
                  </span>
                  <button className="p-2 rounded-xl hover:bg-surface-container-lowest transition-colors">
                    <MoreHorizontal size={18} className="text-tertiary" />
                  </button>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-2xl font-extrabold tracking-tight">Room {room.number}</h3>
                <p className="text-sm font-bold text-secondary uppercase tracking-widest">{room.type}</p>
              </div>

              <div className="flex justify-between items-center pt-6 border-t border-surface-container-high">
                <div>
                  <p className="text-[10px] font-bold text-tertiary uppercase tracking-widest">Price per Night</p>
                  <p className="text-xl font-extrabold text-primary">${room.price}</p>
                </div>
                <button className="px-5 py-2.5 rounded-xl bg-surface-container-lowest text-xs font-bold text-on-surface hover:bg-on-surface hover:text-white transition-all">
                  View Details
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {showForm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowForm(false)}
              className="absolute inset-0 bg-on-surface/20 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, x: 100 }}
              animate={{ scale: 1, opacity: 1, x: 0 }}
              exit={{ scale: 0.95, opacity: 0, x: 100 }}
              className="relative w-full max-w-2xl bg-surface-container-lowest rounded-[40px] p-10 shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto no-scrollbar"
            >
              <div className="absolute top-0 left-0 w-full h-2 primary-gradient" />
              
              <div className="flex justify-between items-center mb-10">
                <div>
                  <h2 className="text-3xl font-extrabold tracking-tight">Create New Room</h2>
                  <p className="text-tertiary font-medium">Add a new room to the hotel inventory.</p>
                </div>
                <button 
                  onClick={() => setShowForm(false)}
                  className="p-3 rounded-2xl hover:bg-surface-container transition-colors"
                >
                  <X size={24} className="text-tertiary" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="flex flex-col items-center gap-4 mb-8">
                  <div className="w-full h-48 rounded-[40px] bg-surface-container flex flex-col items-center justify-center text-tertiary border-2 border-dashed border-outline-variant group cursor-pointer hover:bg-surface-container-high transition-all">
                    <Upload size={32} className="mb-2 group-hover:-translate-y-1 transition-transform" />
                    <span className="text-[10px] font-bold uppercase tracking-widest">Upload Room Image</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Room Number</label>
                    <div className="relative">
                      <Layers className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
                      <input 
                        required
                        type="text" 
                        value={newRoom.number}
                        onChange={(e) => setNewRoom({...newRoom, number: e.target.value})}
                        placeholder="e.g. 101"
                        className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Room Type</label>
                    <select 
                      value={newRoom.type}
                      onChange={(e) => setNewRoom({...newRoom, type: e.target.value as RoomType})}
                      className="w-full bg-surface-container-low border-none rounded-2xl py-4 px-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all appearance-none"
                    >
                      <option value="Standard">Standard</option>
                      <option value="Deluxe">Deluxe</option>
                      <option value="Suite">Suite</option>
                      <option value="Penthouse">Penthouse</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Price per Night ($)</label>
                    <div className="relative">
                      <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
                      <input 
                        required
                        type="number" 
                        value={newRoom.price}
                        onChange={(e) => setNewRoom({...newRoom, price: Number(e.target.value)})}
                        placeholder="120"
                        className="w-full bg-surface-container-low border-none rounded-2xl py-4 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-tertiary uppercase tracking-widest ml-1">Initial Status</label>
                    <select 
                      value={newRoom.status}
                      onChange={(e) => setNewRoom({...newRoom, status: e.target.value as any})}
                      className="w-full bg-surface-container-low border-none rounded-2xl py-4 px-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all appearance-none"
                    >
                      <option value="Available">Available</option>
                      <option value="Cleaning">Cleaning</option>
                      <option value="Maintenance">Maintenance</option>
                    </select>
                  </div>
                </div>

                <div className="flex gap-4 pt-6">
                  <button 
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="flex-1 py-4 rounded-2xl font-bold text-tertiary hover:bg-surface-container transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 py-4 rounded-2xl font-bold text-white primary-gradient shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
                  >
                    Create Room
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default RoomsPage;
