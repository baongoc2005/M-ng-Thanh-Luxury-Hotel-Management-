import React from 'react';
import { 
  Search, 
  Filter, 
  MoreHorizontal, 
  Mail, 
  Phone, 
  Calendar,
  ChevronRight,
  Star
} from 'lucide-react';
import { Customer } from '../types';

const CustomersPage: React.FC = () => {
  const customers: Customer[] = [
    { id: '1', name: 'Nguyen Van A', email: 'a.nguyen@gmail.com', phone: '0901234567', totalBookings: 5, lastStay: '2026-03-22' },
    { id: '2', name: 'Tran Thi B', email: 'b.tran@gmail.com', phone: '0907654321', totalBookings: 2, lastStay: '2026-03-23' },
    { id: '3', name: 'Le Van C', email: 'c.le@gmail.com', phone: '0901112223', totalBookings: 12, lastStay: '2026-03-20' },
    { id: '4', name: 'Pham Thi D', email: 'd.pham@gmail.com', phone: '0903334445', totalBookings: 1, lastStay: '2026-03-24' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-extrabold tracking-tight mb-2">Customer Management</h1>
          <p className="text-tertiary font-medium">View and manage guest profiles and their stay history.</p>
        </div>
      </div>

      <div className="card-container">
        <div className="flex flex-wrap gap-4 justify-between items-center mb-8">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary" size={18} />
            <input 
              type="text" 
              placeholder="Search customers by name, email, or phone..." 
              className="w-full bg-surface-container border-none rounded-2xl py-3 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-primary/20 transition-all"
            />
          </div>
          <div className="flex gap-3">
            <button className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-surface-container text-sm font-bold text-tertiary hover:bg-surface-container-high transition-colors">
              <Filter size={18} />
              Filter
            </button>
            <button className="px-4 py-3 rounded-2xl bg-surface-container text-sm font-bold text-tertiary hover:bg-surface-container-high transition-colors">
              Export CSV
            </button>
          </div>
        </div>

        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left border-separate border-spacing-y-4">
            <thead>
              <tr className="text-xs font-bold text-tertiary uppercase tracking-wider">
                <th className="px-4 pb-2">Customer</th>
                <th className="px-4 pb-2">Contact</th>
                <th className="px-4 pb-2">Total Bookings</th>
                <th className="px-4 pb-2">Last Stay</th>
                <th className="px-4 pb-2 text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((customer) => (
                <tr key={customer.id} className="group hover:bg-surface-container-low transition-colors rounded-2xl">
                  <td className="px-4 py-4 first:rounded-l-2xl">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-surface-container flex items-center justify-center text-primary font-bold shadow-sm">
                        {customer.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-bold">{customer.name}</p>
                          {customer.totalBookings > 10 && (
                            <div className="p-1 rounded-md bg-amber-100 text-amber-600">
                              <Star size={10} fill="currentColor" />
                            </div>
                          )}
                        </div>
                        <p className="text-xs text-tertiary font-medium">ID: {customer.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-tertiary font-medium">
                        <Mail size={12} />
                        {customer.email}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-tertiary font-medium">
                        <Phone size={12} />
                        {customer.phone}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-secondary">{customer.totalBookings}</span>
                      <span className="text-[10px] font-bold text-tertiary uppercase tracking-widest">Bookings</span>
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-2 text-xs text-tertiary font-medium">
                      <Calendar size={14} />
                      {customer.lastStay}
                    </div>
                  </td>
                  <td className="px-4 py-4 last:rounded-r-2xl text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button className="p-2 rounded-xl hover:bg-surface-container transition-colors">
                        <MoreHorizontal size={18} className="text-tertiary" />
                      </button>
                      <button className="p-2 rounded-xl hover:bg-surface-container text-primary transition-colors">
                        <ChevronRight size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CustomersPage;
