import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  BedDouble, 
  CalendarCheck, 
  UserCircle, 
  LogOut,
  Hotel
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface SidebarProps {
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onLogout }) => {
  const navItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
    { icon: Users, label: 'Staff Management', path: '/staff' },
    { icon: BedDouble, label: 'Room Management', path: '/rooms' },
    { icon: CalendarCheck, label: 'Bookings', path: '/bookings' },
    { icon: UserCircle, label: 'Customers', path: '/customers' },
  ];

  return (
    <aside className="w-72 h-screen bg-surface-container-lowest flex flex-col sticky top-0 z-50">
      <div className="p-8 flex items-center gap-3">
        <div className="w-10 h-10 primary-gradient rounded-xl flex items-center justify-center text-white shadow-lg">
          <Hotel size={24} />
        </div>
        <div>
          <h1 className="text-lg font-bold tracking-tight text-primary leading-tight">Mường Thanh</h1>
          <p className="text-[10px] uppercase tracking-[0.2em] font-bold text-tertiary opacity-60">Luxury Atelier</p>
        </div>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-2">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => cn(
              "flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all duration-300 group",
              isActive 
                ? "bg-primary/5 text-primary font-semibold" 
                : "text-tertiary hover:bg-surface-container hover:text-on-surface"
            )}
          >
            <item.icon size={20} className={cn(
              "transition-transform duration-300 group-hover:scale-110",
              "group-[.active]:text-primary"
            )} />
            <span className="text-sm">{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="p-6">
        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl text-error hover:bg-error/5 transition-all duration-300 group"
        >
          <LogOut size={20} className="group-hover:-translate-x-1 transition-transform" />
          <span className="text-sm font-semibold">Logout</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
