import React from 'react';
import { Bell, Search, Settings } from 'lucide-react';

const Topbar: React.FC = () => {
  return (
    <header className="h-20 bg-surface-container-lowest/50 backdrop-blur-md px-8 flex items-center justify-between sticky top-0 z-40">
      <div className="flex-1 max-w-md">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-tertiary group-focus-within:text-primary transition-colors" size={18} />
          <input 
            type="text" 
            placeholder="Search for bookings, rooms, or staff..." 
            className="w-full bg-surface-container-low border-none rounded-2xl py-2.5 pl-12 pr-4 text-sm focus:ring-2 focus:ring-primary/20 transition-all outline-none"
          />
        </div>
      </div>

      <div className="flex items-center gap-6">
        <button className="p-2.5 rounded-xl hover:bg-surface-container transition-colors relative">
          <Bell size={20} className="text-tertiary" />
          <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-primary-container rounded-full border-2 border-surface-container-lowest"></span>
        </button>
        <button className="p-2.5 rounded-xl hover:bg-surface-container transition-colors">
          <Settings size={20} className="text-tertiary" />
        </button>
        
        <div className="h-8 w-[1px] bg-surface-container mx-2"></div>

        <div className="flex items-center gap-3 pl-2">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-bold text-on-surface">Khanh Huyen</p>
            <p className="text-[10px] font-semibold text-tertiary uppercase tracking-wider">General Manager</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-secondary-container flex items-center justify-center text-secondary font-bold shadow-sm">
            KH
          </div>
        </div>
      </div>
    </header>
  );
};

export default Topbar;
