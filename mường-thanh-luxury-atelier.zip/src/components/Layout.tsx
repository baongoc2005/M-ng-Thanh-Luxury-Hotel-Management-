import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, X } from 'lucide-react';

const Layout: React.FC = () => {
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  const handleLogout = () => {
    setShowLogoutModal(true);
  };

  const confirmLogout = () => {
    // In a real app, handle logout logic here
    setShowLogoutModal(false);
    window.location.reload();
  };

  return (
    <div className="flex min-h-screen bg-background text-on-surface">
      <Sidebar onLogout={handleLogout} />
      
      <main className="flex-1 flex flex-col min-w-0">
        <Topbar />
        <div className="p-8 flex-1 overflow-auto no-scrollbar">
          <Outlet />
        </div>
      </main>

      <AnimatePresence>
        {showLogoutModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLogoutModal(false)}
              className="absolute inset-0 bg-on-surface/20 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-md bg-surface-container-lowest rounded-[32px] p-8 shadow-2xl overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-2 primary-gradient" />
              
              <div className="flex justify-between items-start mb-6">
                <div className="w-12 h-12 rounded-2xl bg-error/10 flex items-center justify-center text-error">
                  <AlertCircle size={28} />
                </div>
                <button 
                  onClick={() => setShowLogoutModal(false)}
                  className="p-2 rounded-xl hover:bg-surface-container transition-colors"
                >
                  <X size={20} className="text-tertiary" />
                </button>
              </div>

              <h2 className="text-2xl font-bold mb-2">Confirm Logout</h2>
              <p className="text-tertiary mb-8 leading-relaxed">
                Are you sure you want to log out of the Mường Thanh Luxury Atelier management system?
              </p>

              <div className="flex gap-4">
                <button 
                  onClick={() => setShowLogoutModal(false)}
                  className="flex-1 py-4 rounded-2xl font-bold text-tertiary hover:bg-surface-container transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={confirmLogout}
                  className="flex-1 py-4 rounded-2xl font-bold text-white primary-gradient shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
                >
                  Logout
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Layout;
